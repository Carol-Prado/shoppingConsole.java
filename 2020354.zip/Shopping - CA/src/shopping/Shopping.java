/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopping;


import OrganicFruits.OrganicApple;
import OrganicFruits.OrganicFruits;
import OrganicFruits.OrganicMelon;
import OrganicFruits.OrganicPapaya;
import java.util.Scanner;





/**
 *
 * 
 */
public class Shopping {
    
public static int quantity=1;//the same intenger will be accesseble for the whole class
public static double total=0;// the same double will be accesseble for the whole class
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
         
    

               
       ShoppingBag myBag = new ShoppingBag(); //this is myBag. I can buy things to put in it
        
        Scanner userInput= new Scanner(System.in);
        
        int userEnding=0;
        
        int again;
        
    
                
    
        
    try{     
        
        do{
            System.out.println("\t\t\t\t+====================================+");
            System.out.println("\t\t\t\t              PRODUCTS                ");
            System.out.println("\t\t\t\t   1. Organic Apple                   ");
            System.out.println("\t\t\t\t   2. Organic Papaya                  ");
            System.out.println("\t\t\t\t   3. Organic Melon                   ");
            System.out.println("\t\t\t\t+====================================+");
    
            
        System.out.println("Give a look in our menu and discover our products. To add some product in your cart select JUST THE NUMBER in front of the product(Between 1 to 3)");
        
        int userChoice= userInput.nextInt();//will read the user choice for eche product they want
          /**
           * Accordingly with the user choice they will be brought to some Switch 
           * case 
           * 
           */ 
            switch (userChoice) {
                
                case 1:
                    OrganicFruits Apple= new OrganicApple((double) 2.5, "Apple");//import package OrganicApple
                    
                    Apple.showPrice();// from the package will output some info from the abstract method;
                    
                    System.out.println("How many do you want to add into your bag?");
                    
                    int userAmount1=userInput.nextInt();//input the user amount
                    
                    double price1 = Apple.value();// the price of the product will come from the method from the package
                    
                    double total1= (price1*userAmount1);
                    /**
                     * 
                     * The total price for THIS ITEM is the price multiplied by 
                     * the amount that the user insert
                     * 
                     */  
                    total=total+total1;/**
                     * 
                     * The total of the bill(including all the user choices) 
                     * will be the total of the bill plus the total of the user choice
                     *                                     
                     */ 
                    System.out.println("The total price of "+ userAmount1+ " Apple(s)"+" is (are): "+total1);
                    
                    System.out.println("Would you like to add this item to the bag?");
                    
                    System.out.println("1. Yes, 2. No");
                    
                    again=userInput.nextInt();
                    
                        if(again==1){// if the input from the user is 1 will be included the item to the ShoppingBag
                            
                            myBag.buyItem(Apple);
                            
                            System.out.println("Would you like to choose another item?");
                           
                            System.out.println("1. Yes, 2.No and finish your purchase:");
                           
                            userEnding=userInput.nextInt();
                        }
                        else{//if not will keep going to the steps
                            
                             System.out.println("Would you like to choose another item?");
                             
                             System.out.println("1. Yes, 2.No and finish your purchase:");
                             
                             userEnding=userInput.nextInt();
                            
                        }
                    //THE SAME THAT WAS EXPLAINED IN CASE 1 HAPPENS IN CASE 2 AND 3
                    
                    break;
                    
                case 2:
                    
                    OrganicFruits Papaya= new OrganicPapaya((double) 5.5, "Papaya");
                    Papaya.showPrice();
                    System.out.println("How many do you want to add into your bag?");
                    int userAmount2=userInput.nextInt();
                    double price2 = Papaya.value();
                    double total2= (price2*userAmount2);
                    total=total+total2;
                    System.out.println("The total price of "+ userAmount2+ " Papaya(s)"+" is (are): "+total2);
                    System.out.println("Would you like to add this item to the bag?");
                    System.out.println("1.Yes, 2.No:");
                    again=userInput.nextInt();
                    
                        if(again==1){
                            
                            myBag.buyItem(Papaya);
                            System.out.println("Would you like to choose another item?");
                            System.out.println("1. Yes, 2.No and finish your purchase:");
                            userEnding=userInput.nextInt();
                        }
                        
                        else{
                            
                             System.out.println("Would you like to choose another item?");
                             System.out.println("1. Yes, 2.No and finish your purchase:");
                             userEnding=userInput.nextInt();
                            
                        }
                        
                    break;
                    
                case 3:
                    
                    OrganicFruits Melon= new OrganicMelon((double) 4.5, "Melon");
                    Melon.showPrice();
                    System.out.println("How many do you want to add into your bag?");
                    int userAmount3=userInput.nextInt();
                    double price3 = Melon.value();
                    double total3= (price3*userAmount3);
                    total=total+total3;
                    System.out.println("The total price of "+ userAmount3+ " Melon(s)"+" is (are): "+total3);
                    System.out.println("Would you like to add this item to the bag?");
                    System.out.println("1.Yes, 2.No:");
                    again=userInput.nextInt();
                    
                        if(again==1){
                            
                            myBag.buyItem(Melon);
                            System.out.println("Would you like to choose another item?");
                            System.out.println("1. Yes, 2.No and finish your purchase:");
                            userEnding=userInput.nextInt();
                        }
                        
                        else{
                            
                             System.out.println("Would you like to choose another item?");
                             System.out.println("1. Yes, 2.No and finish your purchase:");
                             userEnding=userInput.nextInt();
                            
                        }
                        
                    break; 
                    
                       
             
                    
                default:
                    
                    System.out.println("Make sure that you are typing the correct information. We couldn`t recognize your choice.");
                    
                    break;
            }
        }
          
                 while(userEnding==1);
                 /**
                  * The loop will keep going while the user press 1 when asked 
                  * if they "Would like to choose another item"
                  * 
                  */
        
           
           System.out.println("The total cost of your shop is: "+total);
           /**
            * this line will print the total cost of the whole order
            * 
            */
                          
           } 
       
                  
       
       catch(Exception e){
           System.out.println("Something went wrong. Try againg following all the steps using just integer numbers.");
           
               }
}
}

    


          
    


