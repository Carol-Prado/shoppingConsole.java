/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OrganicFruits;

/**
 *
 * @author ca_ro
 */
public class OrganicApple extends OrganicFruits {//defining a parent-children relationship between the 2 classes

    public OrganicApple(double price, String fruit) {
        super(price, fruit);//this line will call the parent
    }
    
    
    @Override
    public double value(){// will override what is wroten in the parent class in the method value
       this.price= (double) 2.50;
        return price;
   }
    
    @Override
    public String product (){// will override what is wroten in the parent class in the method product
        this.fruit="Apple";
        return "Apple";
    }
   
    @Override
    public void showPrice(){// will override what is wroten in the parent class in the abstract method
        System.out.println("The price of "+ this.fruit +" is: " + this.price );
           
        
   
    }
}