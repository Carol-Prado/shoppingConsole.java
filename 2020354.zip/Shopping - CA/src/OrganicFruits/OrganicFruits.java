/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OrganicFruits;

/**
 *
 * @author ca_ro
 */
public abstract class OrganicFruits {
      //PROPERTIES ///
   protected String fruit; 
   protected double price;
   
    
      
    //CONSTRUCTORS ///

    /**
     * Here we'll give parameters to create the fruits 
     * @param price, will create the price
     * @param fruit, will create the fruit
     */
    public OrganicFruits(double price, String fruit) {
        //create a default organicFruit
        this.price = price;
        this.fruit= fruit;
    }
    
    //METHODS ////
      
    // it will set the product with price and fruit
 
   
   public double value(){
       this.price=price;
       return price;
   }

    /**
     *
     * @return
     */
    public String product (){
        this.fruit=fruit;
        return fruit;
    }

    /**
     * abstract method -- will show the price of each product
     
     */
    public abstract void showPrice();

   

   

    
    
       
}

